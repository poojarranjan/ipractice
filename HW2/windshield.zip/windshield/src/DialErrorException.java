public class DialErrorException extends Exception {
public DialErrorException() {
super();
}
public DialErrorException(String error) {
super(error);
}
}

