
public class dial {

	private int dialPosition;
	
	public dial(int dPos)
	{
		this.dialPosition=dPos;
	}
	
	public int getDialPosition() {
		return dialPosition;
		}
		// Set the dial position.
		public void setDialPosition(int dialPosition) {
		this.dialPosition = dialPosition;
		}
}
